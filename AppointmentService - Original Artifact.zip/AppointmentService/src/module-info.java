/**
 * 
 */
/**
 * 
 */
module AppointmentService {
	requires junit;
	requires org.junit.jupiter.api;
}