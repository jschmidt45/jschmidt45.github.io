package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
// TODO: Build tests for the backend
@SpringBootTest
class DemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
