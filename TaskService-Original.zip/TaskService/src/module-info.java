/**
 * 
 */
/**
 * 
 */
module TaskService {
	requires org.junit.jupiter.api;
	requires jdk.incubator.vector;
	requires junit;
}